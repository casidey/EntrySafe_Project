from django.urls import path
from . import views

urlpatterns = [
    # Default root URL loads the login page
    path("", views.login_view, name="login"),
    path("login/", views.login_view, name="login"),
    path("register/", views.register_view, name="register"),
    path("home/", views.home_view, name="home"),
]