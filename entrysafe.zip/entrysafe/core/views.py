from django.shortcuts import render


def login_view(request):
  """Renders the EntrySafe Authentication & Access Portal."""
  return render(request, "login.html")


def register_view(request):
  """Renders the EntrySafe Resident Onboarding & Verification Portal."""
  return render(request, "register.html")


def home_view(request):
  """Renders the EntrySafe Resident Dashboard or Home."""
  return render(request, "home.html")